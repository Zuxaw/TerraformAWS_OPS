import logging
import boto3
import requests
import random

logger = logging.getLogger()
logger.setLevel(logging.INFO)
AWS_REGION = "us-east-1"
EC2_RESOURCE = boto3.resource('ec2', region_name=AWS_REGION)
INSTANCE_STATE = 'running'
INSTANCE_TYPE = 't2.micro'
        
def lambda_handler(event, context):

    instances = EC2_RESOURCE.instances.filter(
        Filters=[
            {
                'Name': 'instance-state-name',
                'Values': [
                    INSTANCE_STATE
                ]
            },
            {
                'Name': 'instance-type',
                'Values': [
                    INSTANCE_TYPE
                ]
            }
            # {
            #     'Name': 'tag:Name',
            #     'Values': [
            #         INSTANCE_NAME_TAG_VALUE
            #     ]
            # }
        ]
    )
    for instance in instances:
        if (int(random.uniform(1,10)) % 2) == 1:
            logger.info("Sorry : Stopping {instance.id}")
            instance.stop()

    return {
        'statusCode': 200
    }