import logging
import boto3
import requests
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)
        
def lambda_handler(event, context):

    url = "http://"+os.environ.get('PUBLIC_IP')
    response = requests.get(url=url)
    if response.status_code == 200:
        logger.info("Health {instance.id}: OK")
    else:
        logger.info("Health {instance.id}: KO "+response.status_code)   

    return {
        'statusCode': 200
    }